import { Component, OnInit } from '@angular/core';

import {Dog} from '../domain/dog';
import {DogService} from '../services/dog/dog.service';

@Component({
  selector: 'app-dogs',
  templateUrl: './dog.component.html',
  styleUrls: ['./dog.component.css']
})
export class DogComponent implements OnInit {

    dogs: Dog[];
    dogStatuses: String[];
    constructor(private dogService: DogService) { }


  ngOnInit() {
    this.dogService.getDogs().then(dogs => this.dogs = dogs)
    .then(() => {
        const dogsArray = this.dogs;
        this.dogStatuses = dogsArray.map(dog => dog.status).filter(function(item, i, ar){ return ar.indexOf(item) === i; });
    });
  }

  filterDogs = (filter) => {
    const dogs = [].slice.call(document.querySelectorAll('.dog'));

    dogs.forEach(dog => {
        if (filter === 'all') {
            dog.classList.remove('hidden');
        } else if (dog.classList.contains(filter)) {
            dog.classList.remove('hidden');
        } else {
            dog.classList.add('hidden');
        }
    });
  }

}
