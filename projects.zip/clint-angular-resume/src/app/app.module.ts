import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

// primeng
import { FieldsetModule } from 'primeng/primeng';
import { AccordionModule } from 'primeng/primeng';
import { ChartModule } from 'primeng/primeng';
import { GMapModule } from 'primeng/primeng';
// components
import { AppComponent } from './app.component';
import { IntroComponent } from './components/intro/intro.component';
import { SkillsComponent } from './components/skills/skills.component';
import { WorkHistoryComponent } from './components/work-history/work-history.component';
import { ProjectHighlightsComponent } from './components/project-highlights/project-highlights.component';
import { TimelineComponent } from './components/timeline/timeline.component';

// services
import { SoftSkillsService } from './services/soft-skills.service';
import { TechnologySkillsService } from './services/technology-skills.service';
import { JobsService } from './services/jobs.service';
import { ProjectsService } from './services/projects.service';
import { TimelineService } from './services/timeline.service';


@NgModule({
  declarations: [
    AppComponent,
    IntroComponent ,
    SkillsComponent ,
    WorkHistoryComponent ,
    ProjectHighlightsComponent,
    TimelineComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FieldsetModule,
    AccordionModule,
    ChartModule,
    GMapModule
  ],
  providers: [
      SoftSkillsService,
      TechnologySkillsService,
      JobsService,
      ProjectsService,
      TimelineService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
