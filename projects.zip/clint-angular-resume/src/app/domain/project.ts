export interface Project {
    company?;
    title?;
    start?;
    end?;
    url?;
    description?;
}
