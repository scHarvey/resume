import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

//import { SoftSkill } from '../domain/soft-skill';

@Injectable()
export class SoftSkillsService {

    constructor(private http: HttpClient) { }

    getSkills() {
        /*
        return this.http.get<any>('url')
        .toPromise()
        .then(res => res.data)
        .then(data => data);
        */

        return this.http.get<any>('./assets/data/soft-skills.json')
        .toPromise()
        .then(res => <String[]>res.data)
        .then(data => {
            // console.table(data);
            return data;
        });
    }
}
