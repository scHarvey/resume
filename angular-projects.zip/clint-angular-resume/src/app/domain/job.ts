export interface Job {
    company?;
    title?;
    start?;
    end?;
    url?;
    description?;
}
