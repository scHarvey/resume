import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { TimelineItem } from '../domain/timeline';

@Injectable()
export class TimelineService {

    constructor(private http: HttpClient) { }

    getTimeline() {
        /*
        return this.http.get<any>('url')
        .toPromise()
        .then(res => res.data)
        .then(data => data);
        */

        return this.http.get<any>('./assets/data/timeline.json')
        .toPromise()
        .then(res => <TimelineItem[]>res.data)
        .then(data => data);
    }

}
