export interface TechnologySkill {
    label?;
    skills?;
}