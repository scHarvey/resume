export interface Dog {
    dogId?;
    breed?;
    gender?;
    name?;
    status?;
}
