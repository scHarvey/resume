export interface TimelineItem {
    year?;
    grade?;
    home?;
    memories?;
}
