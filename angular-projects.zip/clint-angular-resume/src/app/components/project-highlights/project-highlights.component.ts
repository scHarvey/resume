import { Component, OnInit } from '@angular/core';

import { Project } from '../../domain/project';
import { ProjectsService } from '../../services/projects.service';

@Component({
  selector: 'app-project-highlights',
  templateUrl: './project-highlights.component.html',
  styleUrls: ['./project-highlights.component.css']
})
export class ProjectHighlightsComponent implements OnInit {

    projects: Project[];

    constructor(private projectsService: ProjectsService) { }

    ngOnInit() {
        this.projectsService.getProjects()
        .then(projects => this.projects = projects)
        .then(() => {
            // console.log(this.projects);
        });
    }

}
