import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Project } from '../domain/project';

@Injectable()
export class ProjectsService {

    constructor(private http: HttpClient) { }
    getProjects() {
        /*
        return this.http.get<any>('url')
        .toPromise()
        .then(res => <Project[]>res.data)
        .then(data => data);
        */

        return this.http.get<any>('./assets/data/projects.json')
        .toPromise()
        .then(res => <Project[]>res.data)
        .then(data => data);
      }
}

