import { Component, OnInit } from '@angular/core';

import { TimelineItem } from '../../domain/timeline';
import { TimelineService } from '../../services/timeline.service';

import { DonutChart } from '../../domain/donutchart';
import { GMap } from 'primeng/primeng';

declare const google;

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {

    timeline: TimelineItem[];
    yearsAlive: Number;
    donutChart: DonutChart;
    mapOptions: {};
    mapOverlays: any[];


    constructor(private timelineService: TimelineService) { }

    ngOnInit() {
        this.mapOptions = {
            center: {lat: 41.6005, lng: -93.598022},
            zoom: 9
        };
        this.mapOverlays = [];

        this.timelineService.getTimeline()
        .then(timelineitems => this.timeline = timelineitems)
        .then(() => {
            this.yearsAlive = this.timeline.length;

            const donutData  = {
                labels: [],
                datasets: [
                    {
                        data: [],
                        backgroundColor: [],
                        hoverBackgroundColor: []
                    }
                ]
            };

            this.timeline.forEach(item => {
                let index =  donutData.labels.indexOf(item.home.street);
                if (donutData.labels.includes(item.home.street)) {
                    //index = donutData.labels.indexOf(item.home.street);
                    donutData.datasets[0].data[index]++;
                } else {
                    donutData.labels.push(item.home.street);

                    // item didn't originally exist, so we need to get the new index
                    index = donutData.labels.indexOf(item.home.street);
                    donutData.datasets[0].data[index] = 1;

                    const color = this.getRandomColor();
                    donutData.datasets[0].backgroundColor[index] = color;
                    donutData.datasets[0].hoverBackgroundColor[index] = color;

                    this.createMapMarker(item.home, this.mapOverlays);
                }
            });

            this.donutChart = donutData;
        });
    }

    getRandomColor() {
        const letters = '0123456789ABCDEF';
        let color = '#';
        for (let i = 0; i < 6; i++) {
          color += letters[Math.floor(Math.random() * 16)];
        }
        return color;
    }

    createMapMarker(address, overlays = this.mapOverlays) {
        const latlng = new google.maps.LatLng(
            parseFloat(address.position.lat), 
            parseFloat(address.position.lng)
        );
        const marker = new google.maps.Marker(
            {
                'title': address.street,
                'position':  {
                    'lat': latlng.lat(),
                    'lng': latlng.lng()
                }
            }
        );
        overlays.push(marker);
    }
}
