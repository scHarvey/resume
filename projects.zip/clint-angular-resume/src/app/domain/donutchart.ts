export interface DonutChart {
    labels?;
    datasets?;
}
