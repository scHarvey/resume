import { TestBed, inject } from '@angular/core/testing';

import { TechnologySkillsService } from './technology-skills.service';

describe('TechnologySkillsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TechnologySkillsService]
    });
  });

  it('should be created', inject([TechnologySkillsService], (service: TechnologySkillsService) => {
    expect(service).toBeTruthy();
  }));
});
