import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Job } from '../domain/job';

@Injectable()
export class JobsService {

    constructor(private http: HttpClient) { }
    getJobs() {
        /*
        return this.http.get<any>('url')
        .toPromise()
        .then(res => <Job[]>res.data)
        .then(data => data);
        */

        return this.http.get<any>('./assets/data/jobs.json')
        .toPromise()
        .then(res => <Job[]>res.data)
        .then(data => data);
      }
}

