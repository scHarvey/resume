export interface SoftSkill {
    skill?;
}