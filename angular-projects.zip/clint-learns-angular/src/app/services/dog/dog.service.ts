
import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Dog } from '../../domain/dog';

@Injectable()
export class DogService {

    constructor(private http: HttpClient) { }
    getDogs() {
        /*
        return this.http.get<any>('https://r3maz2gnq4.execute-api.us-east-1.amazonaws.com/prod/dogs')
        .toPromise()
        .then(res => <Dog[]>res.data)
        .then(data => data);
        */

        return this.http.get<any>('./assets/data/dogs.json')
        .toPromise()
        .then(res => <Dog[]>res.data)
        .then(data => data);
      }
}


/*
[
    {"dogId": "00001", "name": "Star", "breed": "Poodle Mix", "gender": "F", "status": "deceased"}
    {"dogId": "00002", "name": "Zach", "breed": "Siberian Husky", "gender": "M", "status": "deceased"}
    {"dogId": "00003", "name": "Beemer", "breed": "Dalmatian", "gender": "F", "status": "deceased"}
    {"dogId": "00004", "name": "Ronin", "breed": "Dalmatian", "gender": "M", "status": "deceased"}
    {"dogId": "00005", "name": "Homer", "breed": "Pit Mix", "gender": "M", "status": "deceased"}
    {"dogId": "00006", "name": "Scout", "breed": "Border Collie", "gender": "F", "status": "deceased"}
    {"dogId": "00007", "name": "Foxy", "breed": "Golden Retriever Mix", "gender": "F", "status": "alive"}
    {"dogId": "00008", "name": "Wayne", "breed": "Pit Bull", "gender": "M", "status": "deceased"}
]
*/
