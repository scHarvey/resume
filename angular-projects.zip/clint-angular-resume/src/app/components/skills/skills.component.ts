import { Component, OnInit } from '@angular/core';

//import { SoftSkill } from '../../domain/soft-skill';
import { SoftSkillsService } from '../../services/soft-skills.service';

import { TechnologySkill } from '../../domain/technology-skill';
import { TechnologySkillsService } from '../../services/technology-skills.service';

@Component({
  selector: 'app-skills',
  templateUrl: './skills.component.html',
  styleUrls: ['./skills.component.css']
})
export class SkillsComponent implements OnInit {
    softSkills: String[];
    techSkills: TechnologySkill[];

    constructor(
        private softSkillsService: SoftSkillsService,
        private techSkillsService: TechnologySkillsService
    ) { }


  ngOnInit() {
    this.softSkillsService.getSkills()
    .then(skills => this.softSkills = skills)
    .then(() => {
        //console.log(this.softSkills);
    });
    this.techSkillsService.getSkills()
    .then(skills => this.techSkills = skills)
    .then(() => {
        // console.log(this.techSkills);
    });
  }

  /*
  filterDogs = (filter) => {
    const dogs = [].slice.call(document.querySelectorAll('.dog'));

    dogs.forEach(dog => {
        if (filter === 'all') {
            dog.classList.remove('hidden');
        } else if (dog.classList.contains(filter)) {
            dog.classList.remove('hidden');
        } else {
            dog.classList.add('hidden');
        }
    });
  }
  */
}
