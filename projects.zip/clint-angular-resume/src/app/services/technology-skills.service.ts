import 'rxjs/add/operator/toPromise';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { TechnologySkill } from '../domain/technology-skill';

@Injectable()
export class TechnologySkillsService {

    constructor(private http: HttpClient) { }

    getSkills() {
        /*
        return this.http.get<any>('url')
        .toPromise()
        .then(res => res.data)
        .then(data => data);
        */

        return this.http.get<any>('./assets/data/technology-skills.json')
        .toPromise()
        .then(res => <TechnologySkill[]>res.data)
        .then(data => {
            // console.table(data);
            return data;
        });
    }
}
